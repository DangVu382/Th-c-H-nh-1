﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommerce.Domain.Entities
{
    public class Product
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; private set; }

        [Required, MaxLength(200)]
        public string Name { get; private set; } = null!;

        [Column(TypeName = "decimal(12,2)")]
        public decimal Price { get; private set; }

        [MaxLength(1000)]
        public string? Description { get; private set; }

        public int StockQuantity { get; private set; }

        // Navigation (EF Core)
        public ICollection<OrderItem> OrderItems { get; private set; } = new List<OrderItem>();

        // EF Core constructor
        private Product() { }

        // DDD constructor
        public Product(string name, decimal price, int stockQuantity, string? description)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Product name is required");

            if (price <= 0)
                throw new ArgumentException("Price must be positive");

            if (stockQuantity < 0)
                throw new ArgumentException("Stock quantity cannot be negative");

            Name = name;
            Price = price;
            StockQuantity = stockQuantity;
            Description = description;
        }

        public void ChangePrice(decimal newPrice)
        {
            if (newPrice <= 0)
                throw new ArgumentException("Price must be positive");

            Price = newPrice;
        }

        public void ReduceStock(int quantity)
        {
            if (quantity <= 0)
                throw new ArgumentException("Quantity must be positive");

            if (quantity > StockQuantity)
                throw new InvalidOperationException("Insufficient stock");

            StockQuantity -= quantity;
        }

        public void AddStock(int quantity)
        {
            if (quantity <= 0)
                throw new ArgumentException("Quantity must be positive");

            StockQuantity += quantity;
        }
    }
}
