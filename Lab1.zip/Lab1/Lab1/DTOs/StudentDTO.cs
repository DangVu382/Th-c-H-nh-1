﻿namespace Lab1.DTOs
{
    public class StudentDTO
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}